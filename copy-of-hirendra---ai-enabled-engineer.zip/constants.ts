import { Project, Gig, SkillNode } from './types';

export const RESUME_CONTENT = {
  aim: "The objective was to present a concise technical profile that highlighted hands-on coding experience, AI-assisted development workflows, and measurable freelancing outcomes.",
  methods: "I catalogued academic coursework (Data Structures in C, OOPJ, Digital Logic), practical projects (linked lists, Verilog modules, multi-camera smart-city prototype), and self-directed learning in frontend development and React; I exposed AI tools used for prototyping and code generation.",
  results: "The portfolio summarized working prototypes, published research (AIMV 2025), deployed frontend demos with Three.js, and completed paid freelance gigs that delivered UI/UX and backend integrations.",
  conclusion: "The résumé emphasized practical competence with code, familiarity with modern AI tools, and an ability to deliver end-to-end engineering and design outcomes for clients."
};

export const SKILLS: SkillNode[] = [
  { name: 'C/C++', level: 85, category: 'Language', years: 4 },
  { name: 'Python', level: 90, category: 'Language', years: 3 },
  { name: 'JavaScript', level: 95, category: 'Language', years: 5 },
  { name: 'React', level: 92, category: 'Frontend', years: 3 },
  { name: 'Three.js', level: 80, category: 'Frontend', years: 2 },
  { name: 'Node.js', level: 85, category: 'Backend', years: 3 },
  { name: 'SQL', level: 75, category: 'Backend', years: 2 },
  { name: 'Verilog', level: 70, category: 'System', years: 2 },
  { name: 'AI/LLMs', level: 88, category: 'AI', years: 2 },
  { name: 'Git', level: 90, category: 'System', years: 4 },
];

export const PROJECTS: Project[] = [
  {
    id: '1',
    title: 'Smart City Visualizer',
    description: 'Interactive 3D visualization of multi-camera smart-city data streams.',
    tags: ['Three.js', 'React', 'WebSockets', 'Python'],
    link: '#',
    role: 'Solo',
    isFeatured: true,
    aiNote: 'AI used to generate low-poly city assets and optimize geometry logic.',
    image: 'https://picsum.photos/600/400?random=1'
  },
  {
    id: '2',
    title: 'AI-Powered Code Assistant',
    description: 'A VS Code extension that suggests code snippets using local LLMs.',
    tags: ['TypeScript', 'Python', 'LLM', 'VS Code API'],
    link: '#',
    role: 'Team Lead',
    aiNote: 'Core logic prototyped via Gemini API then refined manually.',
    image: 'https://picsum.photos/600/400?random=2'
  },
  {
    id: '3',
    title: 'Verilog CPU Simulator',
    description: 'Web-based simulator for a custom 8-bit RISC processor design.',
    tags: ['React', 'Verilog', 'WASM'],
    link: '#',
    role: 'Solo',
    image: 'https://picsum.photos/600/400?random=3'
  }
];

export const GIGS: Gig[] = [
  {
    id: 'g1',
    title: '3D Web Experiences',
    description: 'I will create interactive 3D websites using Three.js and React Fiber.',
    price: '$300+',
    delivery: '5-7 Days',
    platform: 'Fiverr',
    link: 'https://fiverr.com'
  },
  {
    id: 'g2',
    title: 'Full Stack React App',
    description: 'Modern, scalable single-page applications with Node.js backends.',
    price: '$500+',
    delivery: '10-14 Days',
    platform: 'Fiverr',
    link: 'https://fiverr.com'
  },
  {
    id: 'g3',
    title: 'AI Integration Scripting',
    description: 'Connect your app to OpenAI/Gemini APIs for smart features.',
    price: '$150+',
    delivery: '3 Days',
    platform: 'Direct',
    link: 'mailto:contact@hirendra.dev'
  }
];

export const LINKS = {
  github: "https://github.com",
  linkedin: "https://linkedin.com",
  fiverr: "https://fiverr.com",
  resume: "/resume.pdf"
};
