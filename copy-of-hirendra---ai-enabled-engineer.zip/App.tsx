import React, { useState, useEffect } from 'react';
import { ThemeProvider, useTheme } from './components/Layout/ThemeContext';
import Scene from './components/Hero/Scene';
import SkillGraph from './components/Skills/SkillGraph';
import Konami from './components/EasterEgg/Konami';
import { RESUME_CONTENT, PROJECTS, GIGS, SKILLS, LINKS } from './constants';
import { Project, SkillNode } from './types';
import { Github, Linkedin, FileText, Mail, ExternalLink, Moon, Sun, Code, Terminal, Cpu, Download } from 'lucide-react';

const NavBar = () => {
  const { theme, toggleTheme } = useTheme();
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navClasses = `fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
    isScrolled 
      ? 'bg-white/80 dark:bg-slate-900/80 backdrop-blur-md shadow-lg py-3' 
      : 'bg-transparent py-6'
  }`;

  return (
    <nav className={navClasses}>
      <div className="container mx-auto px-6 flex justify-between items-center">
        <a href="#" className="text-xl font-bold tracking-tighter flex items-center gap-2">
           <Cpu className="w-6 h-6 text-primary" />
           <span className="hidden sm:inline">Hirendra.dev</span>
        </a>
        
        <div className="flex items-center gap-6">
          <ul className="hidden md:flex gap-6 font-medium text-sm">
            <li><a href="#about" className="hover:text-primary transition-colors">About</a></li>
            <li><a href="#resume" className="hover:text-primary transition-colors">Resume</a></li>
            <li><a href="#skills" className="hover:text-primary transition-colors">Skills</a></li>
            <li><a href="#work" className="hover:text-primary transition-colors">Work</a></li>
            <li><a href="#gigs" className="hover:text-primary transition-colors">Services</a></li>
          </ul>
          
          <button 
            onClick={toggleTheme}
            className="p-2 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
            aria-label="Toggle Theme"
          >
            {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
          </button>
          
          <a href="#contact" className="px-4 py-2 bg-primary text-white rounded-2xl text-sm font-semibold hover:bg-blue-600 transition-colors shadow-lg shadow-blue-500/30">
            Hire Me
          </a>
        </div>
      </div>
    </nav>
  );
};

const HeroSection = () => {
  return (
    <section className="relative h-screen w-full flex items-center justify-center">
      <Scene />
      <div className="container mx-auto px-6 relative z-10 pointer-events-none">
        <div className="max-w-3xl pointer-events-auto">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-800/50 dark:bg-slate-100/10 backdrop-blur border border-slate-700/50 text-xs font-mono text-secondary mb-6">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
            </span>
            AI-Enabled Workflow Active
          </div>
          
          <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight leading-tight mb-6 bg-clip-text text-transparent bg-gradient-to-r from-slate-900 via-slate-700 to-slate-900 dark:from-white dark:via-slate-200 dark:to-slate-400">
            Hirendra Kumar Chaurasiya
          </h1>
          
          <h2 className="text-2xl md:text-3xl font-light text-slate-600 dark:text-slate-300 mb-4 flex flex-wrap gap-3">
             <span>Web & Systems Engineer</span>
             <span className="text-primary">•</span>
             <span>AI-Enabled Developer</span>
          </h2>
          
          <p className="text-lg text-slate-600 dark:text-slate-400 max-w-2xl mb-8 leading-relaxed">
            I combine hand-written code with AI toolchains to design 3D web experiences, full-stack apps, and freelance solutions.
          </p>
          
          <div className="flex flex-wrap gap-4">
             <a href={LINKS.resume} download className="flex items-center gap-2 px-6 py-3 bg-slate-200 dark:bg-slate-800 rounded-2xl font-semibold hover:bg-slate-300 dark:hover:bg-slate-700 transition-all">
               <FileText size={18} /> View Resume (PDF)
             </a>
             <a href="#gigs" className="flex items-center gap-2 px-6 py-3 bg-primary text-white rounded-2xl font-semibold hover:bg-blue-600 shadow-lg shadow-blue-500/30 transition-all transform hover:-translate-y-1">
               Hire Me / Gigs
             </a>
          </div>
        </div>
      </div>
      
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce text-slate-400">
        <div className="w-6 h-10 border-2 border-current rounded-full flex justify-center pt-2">
            <div className="w-1 h-2 bg-current rounded-full animate-scroll"></div>
        </div>
      </div>
    </section>
  );
};

const AboutSection = () => {
  return (
    <section id="about" className="py-24 bg-white dark:bg-slate-900 transition-colors">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row gap-12 items-center">
          
          {/* Profile Image */}
          <div className="md:w-1/3 flex justify-center">
            <div className="relative group">
              <div className="absolute -inset-1 bg-gradient-to-r from-primary to-secondary rounded-full blur opacity-25 group-hover:opacity-75 transition duration-1000 group-hover:duration-200"></div>
              <img 
                src="https://picsum.photos/320/320" 
                alt="Hirendra Profile" 
                className="relative w-64 h-64 rounded-full object-cover border-4 border-white dark:border-slate-800 shadow-xl"
              />
            </div>
          </div>
          
          {/* Bio & Facts */}
          <div className="md:w-2/3 space-y-6">
             <h2 className="text-3xl font-bold">About Me</h2>
             <p className="text-lg text-slate-600 dark:text-slate-300 leading-relaxed border-l-4 border-primary pl-6 py-1 italic">
                "I built systems with C and Verilog, crafted web experiences with HTML/CSS/JS/React, and used AI toolchains to accelerate development. I freelance — I ship production code and polished UI/3D visuals."
             </p>

             <div className="bg-slate-50 dark:bg-slate-800/50 p-6 rounded-2xl border border-slate-200 dark:border-slate-700">
               <h3 className="text-sm font-bold flex items-center gap-2 mb-4 uppercase tracking-wider text-slate-400">
                 <Terminal size={16} /> System Info
               </h3>
               <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm font-mono">
                 <div className="flex justify-between border-b border-slate-200 dark:border-slate-700 pb-2">
                    <span className="text-slate-500">Location_</span>
                    <span className="font-bold">India/Nepal (IST/NPT)</span>
                 </div>
                 <div className="flex justify-between border-b border-slate-200 dark:border-slate-700 pb-2">
                    <span className="text-slate-500">Education_</span>
                    <span className="font-bold">B.Tech (CSE)</span>
                 </div>
                 <div className="flex justify-between border-b border-slate-200 dark:border-slate-700 pb-2">
                    <span className="text-slate-500">Languages_</span>
                    <span className="font-bold">English, Hindi</span>
                 </div>
                 <div className="flex justify-between border-b border-slate-200 dark:border-slate-700 pb-2">
                    <span className="text-slate-500">Role_</span>
                    <span className="font-bold">Full Stack & 3D</span>
                 </div>
               </div>
             </div>
          </div>
          
        </div>
      </div>
    </section>
  );
};

const ResumeSection = () => {
    return (
      <section id="resume" className="py-24 bg-slate-50 dark:bg-slate-900/50 border-y border-slate-200 dark:border-slate-800">
        <div className="container mx-auto px-6">
          <div className="max-w-5xl mx-auto">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-primary/10 rounded-xl text-primary">
                  <FileText size={24} />
                </div>
                <div>
                  <h2 className="text-3xl font-bold text-slate-900 dark:text-white">Technical Summary</h2>
                  <p className="text-slate-500">Engineering Approach & Outcomes</p>
                </div>
              </div>
              <a href={LINKS.resume} download className="flex items-center gap-2 px-5 py-2.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg font-medium text-sm hover:border-primary transition-colors shadow-sm">
                  <Download size={16} /> Download PDF
              </a>
            </div>
  
            <div className="bg-white dark:bg-slate-950 rounded-xl shadow-2xl overflow-hidden border border-slate-200 dark:border-slate-800 font-mono text-sm md:text-base">
              {/* Terminal Header */}
              <div className="bg-slate-100 dark:bg-slate-900 px-4 py-3 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <div className="flex gap-2">
                  <div className="w-3 h-3 rounded-full bg-red-400/80"></div>
                  <div className="w-3 h-3 rounded-full bg-yellow-400/80"></div>
                  <div className="w-3 h-3 rounded-full bg-green-400/80"></div>
                </div>
                <div className="text-xs text-slate-400 font-sans">resume_abstract.md</div>
                <div className="w-10"></div> {/* Spacer */}
              </div>
  
              {/* Code Content */}
              <div className="p-6 md:p-10 space-y-8">
                 <div className="grid md:grid-cols-1 gap-8">
                    
                    <div className="relative pl-6 border-l-2 border-primary/30 hover:border-primary transition-colors">
                        <h3 className="text-primary font-bold mb-2 flex items-center gap-2">
                            <span className="text-slate-400 select-none">01</span> // AIM
                        </h3>
                        <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                            {RESUME_CONTENT.aim}
                        </p>
                    </div>

                    <div className="relative pl-6 border-l-2 border-secondary/30 hover:border-secondary transition-colors">
                        <h3 className="text-secondary font-bold mb-2 flex items-center gap-2">
                            <span className="text-slate-400 select-none">02</span> // METHODS
                        </h3>
                        <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                            {RESUME_CONTENT.methods}
                        </p>
                    </div>

                    <div className="relative pl-6 border-l-2 border-blue-500/30 hover:border-blue-500 transition-colors">
                        <h3 className="text-blue-500 font-bold mb-2 flex items-center gap-2">
                            <span className="text-slate-400 select-none">03</span> // RESULTS
                        </h3>
                        <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                            {RESUME_CONTENT.results}
                        </p>
                    </div>

                    <div className="relative pl-6 border-l-2 border-purple-500/30 hover:border-purple-500 transition-colors">
                        <h3 className="text-purple-500 font-bold mb-2 flex items-center gap-2">
                            <span className="text-slate-400 select-none">04</span> // CONCLUSION
                        </h3>
                        <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                            {RESUME_CONTENT.conclusion}
                        </p>
                    </div>

                 </div>
                 
                 <div className="pt-4 border-t border-slate-100 dark:border-slate-800 text-slate-400 text-xs flex gap-4">
                    <span>Ln 42, Col 12</span>
                    <span>UTF-8</span>
                    <span>Markdown</span>
                 </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    );
};

const SkillsSection = () => {
  const [selectedSkill, setSelectedSkill] = useState<SkillNode | null>(null);

  return (
    <section id="skills" className="py-24 bg-white dark:bg-slate-900 overflow-hidden">
      <div className="container mx-auto px-6 relative">
        <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Technical Constellation</h2>
            <p className="text-slate-500 max-w-xl mx-auto">Interactive node graph. Click a node to inspect details.</p>
        </div>

        <div className="relative h-[400px] md:h-[500px] w-full bg-slate-50 dark:bg-slate-950 rounded-3xl shadow-inner border border-slate-200 dark:border-slate-800 backdrop-blur-sm">
            <SkillGraph onSkillSelect={setSelectedSkill} />
            
            {/* Overlay Card for Selected Skill */}
            {selectedSkill && (
                <div className="absolute top-4 right-4 p-6 bg-white dark:bg-slate-800 rounded-2xl shadow-xl border border-slate-100 dark:border-slate-700 max-w-xs animate-in fade-in slide-in-from-bottom-4 z-10">
                    <div className="flex justify-between items-start mb-2">
                        <h3 className="text-xl font-bold text-primary">{selectedSkill.name}</h3>
                        <button onClick={() => setSelectedSkill(null)} className="text-slate-400 hover:text-red-500">&times;</button>
                    </div>
                    <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                            <span>Proficiency:</span>
                            <div className="w-24 h-2 bg-slate-200 dark:bg-slate-700 rounded-full mt-1.5">
                                <div className="h-full bg-secondary rounded-full" style={{ width: `${selectedSkill.level}%`}}></div>
                            </div>
                        </div>
                        <div className="flex justify-between">
                            <span>Experience:</span>
                            <span className="font-mono">{selectedSkill.years} Years</span>
                        </div>
                        <div className="flex justify-between">
                            <span>Category:</span>
                            <span className="px-2 py-0.5 bg-slate-100 dark:bg-slate-700 rounded text-xs">{selectedSkill.category}</span>
                        </div>
                    </div>
                </div>
            )}
        </div>
        
        {/* Simple List Fallback/Supplement */}
        <div className="mt-8 flex flex-wrap justify-center gap-2">
            {SKILLS.map(s => (
                <span key={s.name} className="px-3 py-1 rounded-full text-xs font-mono bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                    {s.name}
                </span>
            ))}
        </div>
      </div>
    </section>
  );
};

const ProjectCard = ({ project }: { project: Project }) => {
  return (
    <div className="group relative bg-white dark:bg-slate-900 rounded-3xl overflow-hidden border border-slate-100 dark:border-slate-800 shadow-sm hover:shadow-xl hover:scale-[1.02] transition-all duration-300 flex flex-col h-full">
      <div className="h-48 overflow-hidden bg-slate-200 dark:bg-slate-800 relative shrink-0">
         <img src={project.image} alt={project.title} className="w-full h-full object-cover opacity-90 group-hover:opacity-100 transition-opacity" />
         {project.isFeatured && (
             <span className="absolute top-4 left-4 bg-yellow-500 text-black text-xs font-bold px-3 py-1 rounded-full shadow-lg">FEATURED</span>
         )}
      </div>
      
      <div className="p-6 flex flex-col flex-grow">
        <h3 className="text-xl font-bold mb-2 flex justify-between items-start">
            {project.title}
            <a href={project.link} className="text-slate-400 hover:text-primary"><ExternalLink size={18}/></a>
        </h3>
        <p className="text-slate-600 dark:text-slate-400 text-sm mb-4 line-clamp-3">
            {project.description}
        </p>
        
        {project.aiNote && (
            <div className="mb-4 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-xl border border-blue-100 dark:border-blue-800/50">
                <p className="text-xs text-blue-700 dark:text-blue-300 flex items-start gap-2">
                    <span className="shrink-0 text-lg">🤖</span> {project.aiNote}
                </p>
            </div>
        )}

        <div className="flex flex-wrap gap-2 mt-auto">
            {project.tags.map(tag => (
                <span key={tag} className="px-2 py-1 text-xs font-mono bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded-md">
                    {tag}
                </span>
            ))}
        </div>
      </div>
    </div>
  );
};

const WorkSection = () => {
  return (
    <section id="work" className="py-24 bg-slate-50 dark:bg-slate-950">
      <div className="container mx-auto px-6">
        <div className="flex justify-between items-end mb-12">
            <div>
                <h2 className="text-3xl font-bold mb-2">Selected Works</h2>
                <p className="text-slate-500">A mix of research, prototypes, and production code.</p>
            </div>
            <a href={LINKS.github} className="hidden md:flex items-center gap-2 text-primary hover:underline">
                View GitHub <Github size={16}/>
            </a>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {PROJECTS.map(p => <ProjectCard key={p.id} project={p} />)}
        </div>
      </div>
    </section>
  );
};

const ServicesSection = () => {
  return (
    <section id="gigs" className="py-24 bg-white dark:bg-slate-900">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl font-bold text-center mb-12">Freelance Services</h2>
        
        <div className="grid md:grid-cols-3 gap-8">
            {GIGS.map(gig => (
                <div key={gig.id} className="flex flex-col bg-slate-50 dark:bg-slate-950 p-8 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm relative overflow-hidden hover:border-primary/50 transition-colors">
                    <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none">
                        <Code size={100} />
                    </div>
                    
                    <h3 className="text-xl font-bold mb-2 z-10">{gig.title}</h3>
                    <p className="text-slate-600 dark:text-slate-400 text-sm mb-6 z-10 flex-grow">{gig.description}</p>
                    
                    <div className="space-y-4 z-10 mt-auto">
                        <div className="flex justify-between items-center text-sm font-mono border-t border-slate-200 dark:border-slate-800 pt-4">
                            <span>Delivery:</span>
                            <span className="text-slate-900 dark:text-white">{gig.delivery}</span>
                        </div>
                        <div className="flex justify-between items-center text-lg font-bold">
                            <span>Starting at</span>
                            <span className="text-secondary">{gig.price}</span>
                        </div>
                        <a href={gig.link} target="_blank" rel="noreferrer" className="block w-full text-center py-3 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-xl font-bold hover:opacity-90 transition-opacity">
                            Hire on {gig.platform}
                        </a>
                    </div>
                </div>
            ))}
        </div>
      </div>
    </section>
  );
};

const ContactSection = () => {
    return (
        <section id="contact" className="py-24 bg-slate-50 dark:bg-slate-950">
            <div className="container mx-auto px-6 max-w-4xl">
                <div className="bg-gradient-to-br from-slate-900 to-slate-800 dark:from-slate-800 dark:to-black text-white rounded-3xl p-8 md:p-12 shadow-2xl overflow-hidden relative">
                    <div className="relative z-10 grid md:grid-cols-2 gap-12">
                        <div>
                            <h2 className="text-3xl font-bold mb-6">Let's Build Something.</h2>
                            <p className="text-slate-300 mb-8">
                                Available for freelance projects and consulting. 
                                Whether it's a 3D web experience or an AI integration, let's talk code.
                            </p>
                            <div className="space-y-4">
                                <a href="mailto:contact@hirendra.dev" className="flex items-center gap-3 text-slate-300 hover:text-white transition-colors">
                                    <Mail className="w-5 h-5" /> contact@hirendra.dev
                                </a>
                                <div className="flex gap-4 pt-4">
                                    <a href={LINKS.linkedin} className="p-2 bg-white/10 rounded-full hover:bg-white/20 transition-colors"><Linkedin size={20} /></a>
                                    <a href={LINKS.github} className="p-2 bg-white/10 rounded-full hover:bg-white/20 transition-colors"><Github size={20} /></a>
                                </div>
                            </div>
                        </div>
                        
                        <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
                            <div>
                                <label className="block text-xs font-mono text-slate-400 mb-1">NAME</label>
                                <input type="text" className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-primary transition-colors text-white" placeholder="John Doe" />
                            </div>
                            <div>
                                <label className="block text-xs font-mono text-slate-400 mb-1">EMAIL</label>
                                <input type="email" className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-primary transition-colors text-white" placeholder="john@example.com" />
                            </div>
                            <div>
                                <label className="block text-xs font-mono text-slate-400 mb-1">MESSAGE</label>
                                <textarea rows={4} className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-primary transition-colors text-white" placeholder="Project details..."></textarea>
                            </div>
                            <button className="w-full bg-primary hover:bg-blue-600 text-white font-bold py-3 rounded-xl transition-colors shadow-lg shadow-blue-900/50">
                                Send Message
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    );
}

const Footer = () => {
    return (
        <footer className="bg-white dark:bg-black py-12 border-t border-slate-200 dark:border-slate-800">
            <div className="container mx-auto px-6 text-center">
                <p className="text-slate-600 dark:text-slate-400 text-sm mb-2">
                    &copy; {new Date().getFullYear()} Hirendra Kumar Chaurasiya.
                </p>
                <div className="flex items-center justify-center gap-2 text-xs text-slate-500 font-mono">
                    <Code size={12} />
                    <span>Site created with Code + AI</span>
                </div>
            </div>
        </footer>
    );
}

const App: React.FC = () => {
  return (
    <ThemeProvider>
      <div className="min-h-screen">
        <Konami />
        <NavBar />
        <main>
            <HeroSection />
            <AboutSection />
            <ResumeSection />
            <SkillsSection />
            <WorkSection />
            <ServicesSection />
            <ContactSection />
        </main>
        <Footer />
      </div>
    </ThemeProvider>
  );
};

export default App;